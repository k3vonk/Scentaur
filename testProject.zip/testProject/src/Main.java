import interfaces.Drivable;
import testProject.Car;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Drivable drive = new Car();
	}

}
