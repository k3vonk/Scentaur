package interfaces;

public interface Drivable {
	
	public int getWheels();
	public int getCapacity();
	public int getDoors();
	public boolean isManual();
}
