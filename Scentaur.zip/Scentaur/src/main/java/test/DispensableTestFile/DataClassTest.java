package test.DispensableTestFile;

public class DataClassTest {
    /**
     *
     *
     *
     *
     *
     */
    int x;
    int y;

    //test
    public DataClassTest(int x, int y, int z){
        this.x = x;
        this.y = y;
    }

    //teststststst
    public void setX(int x){
        this.x = x;
    }
    //sdfsdfsdfsdfsdfsdf
    //testst
    //test

}
