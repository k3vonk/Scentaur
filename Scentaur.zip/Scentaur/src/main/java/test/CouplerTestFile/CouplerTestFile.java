package test.CouplerTestFile;

import com.github.javaparser.ast.Node;

import java.io.File;

public class CouplerTestFile {

    public void Test(){
        File myFile = new File("src/main/java/test/CouplerTestFile");
        myFile.getName().split("").clone().clone().clone();
    }
}
