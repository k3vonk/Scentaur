package test.AbuserTestFile;

public class AbusersTestFile {
    public int x;
    private String y;
    public Boolean bool;


    public void switchStat(){
        switch(5){
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            default:
                break;
        }
    }
}
