package test.AbuserTestFile;

public class AbuserNormalTest {
    /**
     *
     *
     *
     *
     *
     */
    int x;
    int y;

    //test
    public AbuserNormalTest(int x, int y, int z){
        this.x = x;
        this.y = y;
    }

    //teststststst
    public void setX(int x){
        this.x = x;
    }
    //sdfsdfsdfsdfsdfsdf
    //testst
    //test

}
