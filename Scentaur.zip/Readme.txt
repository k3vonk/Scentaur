The team behind Scentaur was very limited on time during the month of April.
Due to numerous full projects such as web design and game development along with a bunch of other assignments from
each module.

As a result our project was not completed for the Monday submission.
Instead we used Monday to Friday to create a full bodied project in order to achieve most of the goals for Scentaur.

The first submission had incredibly low amount of working functionalities. And does not function properly.
This submission however, uses a server and fully detects smells. We assumed through Fintan's email that this
resubmission was not a late submission as it does not mention such. 

Fintan's email:
"He explained that the correcting process will involve a full read through of all submitted project work, checking that everything is present, gathering data, planning the grading process etc (starting from the Monday), and then a more detailed analysis and detailed grading of each project (starting on Friday).  

Given this he's tried to help alleviate the pressure on you guys as follows:
He has to require that you submit your project by the Monday deadline,
BUT will allow you to upload revisions etc later in the week, as long as
those revisions are uploaded before Friday morning (when the detailed grading starts). 

So you still have to SUBMIT by Monday morning, but can upload revisions up to Friday morning"

This is a major revision.

Updates include:
1. More smells
2. Change in Smell abstract class
3. Detector classes (Abuser, Bloater, Dispendable, Coupler)
4. Tomcat, JavaScript, HTML, CSS for front end
5. Servlets to connect java and the front-end

Extra way of importing:
1. Send everything onto a folder in this zip file.
2. Import THAT folder so itll include .metadata, Scentaur, Server
3. Follow normal procedure on pdf by installing plugins.
4. Run as server Tomcat v8.5

We the team at Scentaur apologize for any inconvenience in supplying a more full bodied solution to the project.
We hope you enjoy the workings of Scentaur.

P.S. I sent Philip an email at around 6 am Friday 03/05/2019 about the resubmission and that he had not opened the update
resubmission before then. As the team was worried, we had submitted a zip onto the Report only submission link.
Changes have been made ever since to fix that problem. But do note that is the reason why the Report file has a late
timer submission. Thanks

Yours Sincerely,
Team behind Scentaur
